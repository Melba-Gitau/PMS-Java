<div class = "container">
<h1>JOB details:</h1>
<form action="/apply" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" placeholder="title"><br><br>
    <input type="text" name="contract" placeholder="contract type"><br><br>
    <input type="textarea" name="desc" placeholder="description"><br><br>
    <input type="text" name="date" placeholder="input date"><br><br>
    <button type="submit">Apply</button>
</form>
</div>
<style>
*{
    margin:0;
    padding:0;
}
.container{
    margin-left:30%;
    margin-top:10%;
    padding:5px;
}
</style>
<?php /**PATH C:\Users\Mel'\Desktop\assignment\web_app\resources\views/application.blade.php ENDPATH**/ ?>